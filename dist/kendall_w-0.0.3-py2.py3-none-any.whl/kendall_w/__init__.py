from .kendall_w import compute_w

# Next version: usage goes from 
# `from kendall_w.kendall_w import compute_w` to
# `from kendall_w import compute-w`

__all__ = ['kendall_w']
__version__ = (0, 0, 3)