from .kendall_w import compute_w

__version__ = (1, 0, 0)